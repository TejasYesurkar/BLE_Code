package com.manager.servicesble_code.bluetoothDevice;

import android.view.View;

public interface ItemClickListener {

    void onGetAddress(String string);
}
